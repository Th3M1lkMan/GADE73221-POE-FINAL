using UnityEngine;

public class BaseDamageEffect : MonoBehaviour
{
    private Material baseMaterialInstance; 
    public float flashDuration = 0.5f;     
    private float flashTimer = 0f;

    void Start()
    {
        // Get the material instance applied to this object
        baseMaterialInstance = GetComponent<Renderer>().material;
        baseMaterialInstance.SetFloat("_DamageFlashAmount", 0); 
        Debug.Log("Base material initialized with flash amount = 0");
    }

    public void TakeDamage()
    {
       
        baseMaterialInstance.SetFloat("_DamageFlashAmount", 1);
        Debug.Log("Damage taken, flashing color. Flash Amount = 1");
        flashTimer = flashDuration;  // Start the flash timer
    }

    void Update()
    {
      
        if (flashTimer > 0)
        {
            flashTimer -= Time.deltaTime;
            if (flashTimer <= 0)
            {
                
                baseMaterialInstance.SetFloat("_DamageFlashAmount", 0);
                Debug.Log("Flash time over, resetting flash amount to 0");
            }
        }
    }
}