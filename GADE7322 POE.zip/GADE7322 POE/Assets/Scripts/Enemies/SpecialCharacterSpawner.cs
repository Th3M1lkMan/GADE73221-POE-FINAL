using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialCharacterSpawner : MonoBehaviour
{
    public GameObject spherePrefab;
    public GameObject cubePrefab;
    public GameObject capsulePrefab;
    public Color[] colors = { Color.blue, Color.red, Color.green, Color.yellow };

    public void Start()
    {
        SpawnSpecialCharacter();
    }

    void SpawnSpecialCharacter()
    {
        GameObject[] shapes = { spherePrefab, cubePrefab, capsulePrefab };
        int shapeIndex = Random.Range(0, shapes.Length);
        GameObject specialCharacterPrefab = shapes[shapeIndex];

        int colorIndex = Random.Range(0, colors.Length);
        Color specialColor = colors[colorIndex];

        float randomSpeed = Random.Range(1f, 5f);

        
        Vector3 spawnPoint = GetRandomEdgePosition();
        spawnPoint.y = 1f;

        GameObject specialCharacter = Instantiate(specialCharacterPrefab, spawnPoint, Quaternion.identity);

        specialCharacter.GetComponent<Renderer>().material.color = specialColor;
        Attackers enemyScript = specialCharacter.GetComponent<Attackers>();
        enemyScript.speed = randomSpeed;
    }

    Vector3 GetRandomEdgePosition()
    {
        int gridSize = 100; 
        int side = Random.Range(0, 4);
        int position = Random.Range(0, gridSize);

        switch (side)
        {
            case 0: return new Vector3(position, 0, 0);
            case 1: return new Vector3(gridSize - 1, 0, position);
            case 2: return new Vector3(position, 0, gridSize - 1);
            case 3: return new Vector3(0, 0, position);
            default: return new Vector3(0, 0, 0);
        }
    }
}