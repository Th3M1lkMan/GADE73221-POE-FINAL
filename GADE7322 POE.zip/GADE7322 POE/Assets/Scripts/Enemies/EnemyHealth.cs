using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyHealth : MonoBehaviour
{
    public float maxHealth = 100f;
    private float currentHealth;
    public GameObject healthBarPrefab;
    private GameObject healthBarInstance;
    private Slider healthBarSlider;
    public GameObject deathParticlePrefab;
    private float shakeDuration = 0.5f;
    private float shakeTimer;
    private bool isShaking;
    private Vector3 originalPosition;

    void Start()
    {
        currentHealth = maxHealth;
        originalPosition = transform.position;
        GameObject canvas = GameObject.Find("Canvas");
        if (healthBarPrefab != null && canvas != null)
        {
            healthBarInstance = Instantiate(healthBarPrefab, canvas.transform);
            healthBarSlider = healthBarInstance.GetComponentInChildren<Slider>();
            healthBarSlider.maxValue = maxHealth;
            healthBarSlider.value = currentHealth;
        }
    }

    void Update()
    {
        if (healthBarInstance != null)
        {
            Vector3 healthBarPosition = Camera.main.WorldToScreenPoint(transform.position + Vector3.up * 2);
            healthBarInstance.transform.position = healthBarPosition;
        }

        if (isShaking)
        {
            if (shakeTimer > 0)
            {
                transform.position = originalPosition + Random.insideUnitSphere * 0.1f;
                shakeTimer -= Time.deltaTime;
            }
            else
            {
                isShaking = false;
                transform.position = originalPosition;
            }
        }
    }

    public void TakeDamage(float amount)
    {
        currentHealth -= amount;
        if (healthBarSlider != null)
        {
            healthBarSlider.value = currentHealth;
        }

        if (currentHealth <= 0)
        {
            PlayDeathParticles();
            DestroyHealthBar();
            Destroy(gameObject);
        }
        else
        {
            StartShaking();
        }
    }

    void StartShaking()
    {
        shakeTimer = shakeDuration;
        isShaking = true;
    }

    void DestroyHealthBar()
    {
        if (healthBarInstance != null)
        {
            Destroy(healthBarInstance);
        }
    }

    void PlayDeathParticles()
    {
        if (deathParticlePrefab != null)
        {
            GameObject deathParticles = Instantiate(deathParticlePrefab, transform.position, Quaternion.identity);
            ParticleSystem particleSystem = deathParticles.GetComponent<ParticleSystem>();
            if (particleSystem != null)
            {
                particleSystem.Play();
            }
            Destroy(deathParticles, particleSystem.main.duration);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            PlayDeathParticles();
        }
    }
}