using UnityEngine;

public class Shop : MonoBehaviour
{
    public XPManager xpManager;

    public GameObject defender1Prefab;
    public GameObject defender2Prefab;
    public GameObject defender3Prefab;
    public GameObject ballista1Prefab;
    public GameObject ballista2Prefab;
    public GameObject ballista3Prefab;
    public GameObject swordsmen1Prefab;
    public GameObject swordsmen2Prefab;
    public GameObject swordsmen3Prefab;

    public void PurchaseDefender1()
    {
        PurchaseCharacter(defender1Prefab, 1);
    }

    public void PurchaseDefender2()
    {
        PurchaseCharacter(defender2Prefab, 2);
    }

    public void PurchaseDefender3()
    {
        PurchaseCharacter(defender3Prefab, 3);
    }

    public void PurchaseBallista1()
    {
        PurchaseCharacter(ballista1Prefab, 2);
    }

    public void PurchaseBallista2()
    {
        PurchaseCharacter(ballista2Prefab, 4);
    }

    public void PurchaseBallista3()
    {
        PurchaseCharacter(ballista3Prefab, 8);
    }

    public void PurchaseSwordsmen1()
    {
        PurchaseCharacter(swordsmen1Prefab, 2);
    }

    public void PurchaseSwordsmen2()
    {
        PurchaseCharacter(swordsmen2Prefab, 3);
    }

    public void PurchaseSwordsmen3()
    {
        PurchaseCharacter(swordsmen3Prefab, 4);
    }

    private void PurchaseCharacter(GameObject characterPrefab, int cost)
    {
        if (xpManager.SpendXP(cost))
        {
            Instantiate(characterPrefab, transform.position, Quaternion.identity);
        }
        else
        {
            Debug.Log("Not enough XP to purchase this character.");
        }
    }
}