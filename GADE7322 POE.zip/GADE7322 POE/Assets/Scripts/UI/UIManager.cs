using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public Deffenders deffendersScript;
    public GameObject storePanel;       
    public Button storeButton;          
    public Button[] itemButtons;        

    private bool storeOpen = false;

    void Start()
    {
        
        storePanel.SetActive(false);

        
        storeButton.onClick.AddListener(OpenStore);

       
        for (int i = 0; i < itemButtons.Length; i++)
        {
            int index = i; 
            itemButtons[i].onClick.AddListener(() => SelectItem(index));
        }
    }

    public void ExitGame()
    {
        SceneManager.LoadScene(0);
    }

    public void LeaderBoard()
    {
        SceneManager.LoadScene(2);
    }

    public void CloseGame()
    {
        Application.Quit();
        Debug.Log("Game Quit");
    }

    public void SetSelectedDefender(int index)
    {
        deffendersScript.SetSelectedDefender(index);
    }

  
    private void OpenStore()
    {
        Debug.Log("Store button clicked");
        storePanel.SetActive(true);
        storeOpen = true;
    }

    
    public void CloseStore()
    {
        storePanel.SetActive(false);
        storeOpen = false;
    }

    public bool IsStoreOpen()
    {
        return storeOpen;
    }

   
    private void SelectItem(int itemIndex)
    {
        deffendersScript.SetSelectedDefender(itemIndex);
        CloseStore();
    }
}