using UnityEngine;

public class DefenderGridGeneration : MonoBehaviour
{
    public int gridSize = 10;
    public float tileSize = 1.0f;
    public GameObject gridTilePrefab;
    public Vector3 gridOrigin = new Vector3(0, 0, 0);
    public Material hoverMaterial;
    private Material originalMaterial;
    private GameObject lastHoveredTile;

    void Start()
    {
        GenerateGrid();
    }

    void Update()
    {
        HandleMouseHover();
    }

    void GenerateGrid()
    {
        for (int x = 0; x < gridSize; x++)
        {
            for (int y = 0; y < gridSize; y++)
            {
                Vector3 position = new Vector3(x * tileSize, 0, y * tileSize) + gridOrigin;
                Instantiate(gridTilePrefab, position, Quaternion.identity);
            }
        }
    }

    void HandleMouseHover()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hit))
        {
            GameObject hitTile = hit.collider.gameObject;
            if (hitTile != lastHoveredTile)
            {
                if (lastHoveredTile != null)
                {
                    lastHoveredTile.GetComponent<Renderer>().material = originalMaterial;
                }

                originalMaterial = hitTile.GetComponent<Renderer>().material;
                hitTile.GetComponent<Renderer>().material = hoverMaterial;
                lastHoveredTile = hitTile;
            }
        }
        else if (lastHoveredTile != null)
        {
            lastHoveredTile.GetComponent<Renderer>().material = originalMaterial;
            lastHoveredTile = null;
        }
    }
}