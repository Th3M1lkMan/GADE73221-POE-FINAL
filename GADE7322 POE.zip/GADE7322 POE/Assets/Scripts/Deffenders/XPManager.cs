using UnityEngine;
using TMPro;

public class XPManager : MonoBehaviour
{
    public float xpPerSecond = 1.0f;
    public TextMeshProUGUI xpText;

    private float currentXP = 0f;

    void Start()
    {
        UpdateXPText();
    }

    void Update()
    {
        currentXP += xpPerSecond * Time.deltaTime;
        UpdateXPText();
    }

    void UpdateXPText()
    {
        xpText.text = "XP: " + Mathf.FloorToInt(currentXP).ToString();
    }

    public bool SpendXP(float amount)
    {
        if (currentXP >= amount)
        {
            currentXP -= amount;
            UpdateXPText();
            return true;
        }
        return false;
    }
}