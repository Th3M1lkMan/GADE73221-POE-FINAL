using UnityEngine;
using TMPro;

public class Deffenders : MonoBehaviour
{
    public GameObject[] defenderPrefabs;
    public LayerMask greenTileLayer;
    public LayerMask riverLayer;
    public float placementOffset = 0.5f;
    public TextMeshProUGUI defenderNameText;
    public UIManager uiManager;

    private GameObject selectedDefender;

    void Update()
    {
        if (Input.GetMouseButtonDown(0) && selectedDefender != null && !uiManager.IsStoreOpen())
        {
            Vector3 mousePosition = Input.mousePosition;
            Ray ray = Camera.main.ScreenPointToRay(mousePosition);
            if (Physics.Raycast(ray, out RaycastHit hit, Mathf.Infinity, greenTileLayer))
            {
                Vector3 hitPoint = hit.point;
                if (!IsOnRiver(hitPoint))
                {
                    hitPoint.y = TileHeight(hitPoint) + placementOffset;
                    PlaceDefender(hitPoint);
                    selectedDefender = null;
                }
            }
        }
    }

    bool IsOnRiver(Vector3 position)
    {
        return Physics.Raycast(position + Vector3.up * 10, Vector3.down, out _, Mathf.Infinity, riverLayer);
    }

    float TileHeight(Vector3 position)
    {
        if (Physics.Raycast(position + Vector3.up * 10, Vector3.down, out RaycastHit hit, Mathf.Infinity, greenTileLayer))
        {
            return hit.point.y;
        }
        return 0;
    }

    void PlaceDefender(Vector3 position)
    {
        Instantiate(selectedDefender, position, Quaternion.identity);
        UpdateDefenderNameText(null);
    }

    public void SetSelectedDefender(int index)
    {
        if (index >= 0 && index < defenderPrefabs.Length)
        {
            selectedDefender = defenderPrefabs[index];
            UpdateDefenderNameText(selectedDefender);
        }
    }

    void UpdateDefenderNameText(GameObject defender)
    {
        if (defender != null)
        {
            defenderNameText.text = "Selected Defender: " + defender.name;
        }
        else
        {
            defenderNameText.text = "No Defender Selected";
        }
    }
}